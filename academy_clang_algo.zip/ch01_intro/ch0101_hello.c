//
//	file name:	p0101_hello.c
//	author:		Jung,JaeJoon(rgbi3307@nate.com, http://www.kernel.bz/)
//	comments:	���ڿ� ����ϱ�
//

#include <stdio.h>

main()
{
	printf("The first C program\n");
}

