/*
ch0101_hello_01.c
-------------------------------------------------------------------------------
	1.1 Getting Started
	Print the words
	hello, world 
editted by Jung,JaeJoon(rgbi3307@nate.com, http://www.kernel.bz/)
-------------------------------------------------------------------------------
*/

#include <stdio.h>
main()
{
	printf("hello, world\n");
}

