/*
ch0101_hello_02.c
-------------------------------------------------------------------------------
	1.1 Getting Started
	printf never supplies a newline character automatically.
	Notice that \n represents only a single character.
editted by Jung,JaeJoon(rgbi3307@nate.com, http://www.kernel.bz/)
-------------------------------------------------------------------------------
*/

#include <stdio.h>
main()
{
	printf("hello, ");
	printf("world");
	printf("\n");
}

