#ifndef MEM_H
#define MEM_H

#include <stdlib.h>

struct tnode *talloc(void);
//char *strdup(char *);

#endif
