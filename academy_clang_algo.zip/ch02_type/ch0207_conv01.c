/*
	file name:	ch0207_conv01.c
	author:		Jung,JaeJoon(rgbi3307@nate.com, http://www.kernel.bz/)
	comments:	����ȯ
*/

#include <stdio.h>

main ()
{
	char c;
	int  i;
	float x;
	double d;

	c = 'A';
	i = c;
	c = i;
	printf("c=%c\n", c);

	i = 10;
	x = i;
	i = x;
	printf("i=%d\n", i);

	x = 3.14;
	i = x;
	printf("x=%f, i=%d, i=%f\n", x, i, (float)i);

	d = 2.718259238;
	x = d;
	printf("d=%1.9f, x=%1.9f\n", d, x);

	d = (double)i;
	printf("d=%f\n", d);

	printf("Press any key to end...");
	getchar();
}
