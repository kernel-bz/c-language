/*
	file name:	ch0211_cond01.c
	author:		Jung,JaeJoon(rgbi3307@nate.com, http://www.kernel.bz/)
	comments:	���� ǥ��
*/

#include <stdio.h>

main ()
{
    int  a = 10;
    int  b = 20;
    int  z, n;

    z = (a > b) ? a : b;
    printf ("z = %d\n", z);

	n = 10;
	printf("You have %d item%s.\n", n, n==1 ? "" : "s");
	n = 1;
	printf("You have %d item%s.\n", n, n==1 ? "" : "s");

	printf("\nPress any key to end...");
	getchar();
}
