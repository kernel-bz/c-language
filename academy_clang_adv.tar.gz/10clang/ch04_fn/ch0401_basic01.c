/*
	file name:	ch0401_basic01.c
	author:		Jung,JaeJoon(rgbi3307@nate.com, http://www.kernel.bz/)
	comments:	�Լ��� ����
*/

#include <stdio.h>

main ()
{
	int a = 10, b = 20;

	printf("a = %d\n", a);
	printf("b = %d\n", b);
	printf("a+b = %d\n", a + b);

	printf("\nPress any key to end...");
	getchar();
}

