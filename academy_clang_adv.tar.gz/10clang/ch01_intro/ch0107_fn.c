/*
ch0107_fn.c
-------------------------------------------------------------------------------
	1.7 Functions
	1.8 Arguments - Call by Value
editted by Jung,JaeJoon(rgbi3307@nate.com, http://www.kernel.bz/)
-------------------------------------------------------------------------------
*/
#include <stdio.h>
int power(int m, int n);
/* test power function */
main()
{
    int i;
    for (i = 0; i < 10; ++i)
        printf("%d %d %d\n", i, power(2,i), power(-3,i));
    return 0;
}
/* power:  raise base to n-th power; n >= 0 */
int power(int base, int n)
{
    int i,  p;
    p = 1;
    for (i = 1; i <= n; ++i)
        p = p * base;
    return p;
}

